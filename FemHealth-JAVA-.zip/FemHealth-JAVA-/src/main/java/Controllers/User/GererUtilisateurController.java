package Controllers.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class GererUtilisateurController {
    @FXML
    private ChoiceBox<String> choix_type;

    @FXML
    private Button btnModifier;

    @FXML
    private TextField textField;

    @FXML
    private Button btnBloquer;

    @FXML
    private TableView<Utilisateur> tableView;

    @FXML
    private TableColumn<Utilisateur, Integer> idCol;

    @FXML
    private TableColumn<Utilisateur, String> emailCol;

    @FXML
    private TableColumn<Utilisateur, String> roleCol;

    @FXML
    private TableColumn<Utilisateur, String> statutCol;

    @FXML
    private Button btnDeconnecter;

    private ObservableList<Utilisateur> utilisateurs = FXCollections.observableArrayList();

    @FXML
    private void initialize() {

        choix_type.getItems().addAll("Admin", "Utilisateur");

        utilisateurs.add(new Utilisateur(1, "example@example.com", "Admin", "Actif"));
        utilisateurs.add(new Utilisateur(2, "user@example.com", "Utilisateur", "Bloqué"));

        idCol.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        emailCol.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        roleCol.setCellValueFactory(cellData -> cellData.getValue().roleProperty());
        statutCol.setCellValueFactory(cellData -> cellData.getValue().statutProperty());

        tableView.setItems(utilisateurs);
    }

    @FXML
    private void ModifierRole() {
        // Code à exécuter lors de la modification du rôle de l'utilisateur
        String nouveauRole = choix_type.getValue();
        // Ajoutez ici le code pour modifier le rôle de l'utilisateur sélectionné dans la TableView
    }

    @FXML
    private void bloquer() {

    }

    @FXML
    private void deconnecter() {

    }
}
