package Controllers.User;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class InscriptionController {
    @FXML
    private TextField EmailTF;

    @FXML
    private TextField mdpTF;

    @FXML
    private Button inscrireButton;

    @FXML
    private void initialize() {

    }

    @FXML
    private void HomePage() {

        String email = EmailTF.getText();
        String motDePasse = mdpTF.getText();

    }
}
