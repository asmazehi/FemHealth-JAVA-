package Controllers.User;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Utilisateur {

        private final SimpleIntegerProperty id;
        private final SimpleStringProperty email;
        private final SimpleStringProperty role;
        private final SimpleStringProperty statut;

        public Utilisateur(int id, String email, String role, String statut) {
            this.id = new SimpleIntegerProperty(id);
            this.email = new SimpleStringProperty(email);
            this.role = new SimpleStringProperty(role);
            this.statut = new SimpleStringProperty(statut);
        }

        public int getId() {
            return id.get();
        }

        public SimpleIntegerProperty idProperty() {
            return id;
        }

        public String getEmail() {
            return email.get();
        }

        public SimpleStringProperty emailProperty() {
            return email;
        }

        public String getRole() {
            return role.get();
        }

        public SimpleStringProperty roleProperty() {
            return role;
        }

        public String getStatut() {
            return statut.get();
        }

        public SimpleStringProperty statutProperty() {
            return statut;
        }
    }

