package Controllers.User;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


    public class AuthentificationController {

        @FXML
        private TextField EmailTF;

        @FXML
        private TextField mdpTF;

        @FXML
        private Button seConnecterButton;

        @FXML
        private Label motDePasseOublieLabel;

        @FXML
        private void initialize() {
            // Ajoutez ici du code d'initialisation
        }

        @FXML
        private void seConnecter() {
            // Code à exécuter lors du clic sur le bouton "se connecter"
            String email = EmailTF.getText();
            String motDePasse = mdpTF.getText();
            // Ajoutez ici le code pour traiter l'authentification de l'utilisateur
        }

        @FXML
        private void motDePasseOublie() {
            // Code à exécuter lors du clic sur le lien "Mot de passe oublié?"
            // Ajoutez ici le code pour gérer la réinitialisation du mot de passe
        }
    }
