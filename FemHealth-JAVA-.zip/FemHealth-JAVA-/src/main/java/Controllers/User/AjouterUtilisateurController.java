package Controllers.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.User.Utilisateur;
import service.User.UtilisateurService;

import java.sql.SQLException;

public class AjouterUtilisateurController {

    @FXML
    private TextField NomTF;

    @FXML
    private TextField emailTF;

    @FXML
    private TextField mdpTF;

    @FXML
    private AnchorPane nom;

    @FXML
    void AfficherUtilisateurs(ActionEvent event) {

    }

    @FXML
    void AjouterUtilisateur(ActionEvent event) {
        String nom = NomTF.getText();
        String email = emailTF.getText();
        String mdp = mdpTF.getText();
        Utilisateur p = new Utilisateur(nom,email,mdp);
        UtilisateurService us = new UtilisateurService();
        try {
            us.add(p);
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Succes");
            alert.setContentText("Utilisateur ajoute");
            alert.show();
        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setContentText(e.getMessage());
            alert.show();

        }

    }


}

