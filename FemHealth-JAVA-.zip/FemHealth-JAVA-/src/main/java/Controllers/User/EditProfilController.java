package Controllers.User;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class EditProfilController {
    @FXML
    private TextField EmailTF;

    @FXML
    private CheckBox changemdp;

    @FXML
    private PasswordField mdpAC_TF;

    @FXML
    private PasswordField mdpNV_TF;

    @FXML
    private PasswordField mdpC_TF;

    @FXML
    private Button confirmationButton;

    @FXML
    private void initialize() {

    }

    @FXML
    private void Modifiermdp() {

        if (changemdp.isSelected()) {

            mdpAC_TF.setVisible(true);
            mdpNV_TF.setVisible(true);
            mdpC_TF.setVisible(true);
        } else {

            mdpAC_TF.setVisible(false);
            mdpNV_TF.setVisible(false);
            mdpC_TF.setVisible(false);
        }
    }

    @FXML
    private void ModifierInfo() {

        String email = EmailTF.getText();
        String motDePasseActuel = mdpAC_TF.getText();
        String nouveauMotDePasse = mdpNV_TF.getText();
        String confirmationMotDePasse = mdpC_TF.getText();

        System.out.println("Email: " + email);
        System.out.println("Mot de passe actuel: " + motDePasseActuel);
        System.out.println("Nouveau mot de passe: " + nouveauMotDePasse);
        System.out.println("Confirmation du mot de passe: " + confirmationMotDePasse);
    }
}
